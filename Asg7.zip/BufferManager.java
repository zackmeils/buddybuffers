/**
* Zack Meilstrup, Asg 7, 5/11/2023
* This program is the buffer manager for the buddy buffer program.
**/

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class BufferManager {

    private LinkedList<Buffers> bufferList = null;
    private int maxBufferSize = 0;
    private int minBufferSize = 0;
    private boolean tightPool = false;
    private String status = null;
    
    public String getStatus(){
        if(isTightPool()){
            return "tight";
        }else{
            return "OK";
        }
    }

    public LinkedList<Buffers> getBufferList() {
        return bufferList;
    }

    public void setBufferList(LinkedList<Buffers> bufferList) {
        this.bufferList = bufferList;
    }

    public int getMaxBufferSize() {
        return maxBufferSize;
    }

    public void setMaxBufferSize(int maxBufferSize) {
        this.maxBufferSize = maxBufferSize;
    }

    public boolean isTightPool() {
        return tightPool;
    }

    public void setTightPool(boolean tightPool) {
        this.tightPool = tightPool;
    }


    public void BufferManager(int listSize, int bufferMax, int bufferMin){

        this.maxBufferSize = bufferMax;
        this.minBufferSize = bufferMin;
        this.bufferList = buildBuffer(listSize, this.maxBufferSize, this.minBufferSize);
        setStatus(bufferDebug());
    }

    private LinkedList<Buffers> buildBuffer(int listSize,int maxBufferSize, int minBufferSize) {
        LinkedList<Buffers> bufferList = new LinkedList<>();
        for(int i = 0;i<listSize;i++){
            Buffers newBuffer = new Buffers();
            newBuffer.Buffer(maxBufferSize,minBufferSize,null);
            bufferList.add(newBuffer);
        }
        return bufferList;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String bufferDebug(){
        String bufferStatus = null;
        ArrayList<String> bufferStatusList = buildAvailableBt();
        String bufferSizeCounts = getBStatus(bufferStatusList);
        return String.format("Expected Values: %s Status: %s",bufferSizeCounts, getStatus());
    }

    private ArrayList<String> buildAvailableBt() {
        ArrayList returnBufferList = new ArrayList();
        for(int i = 0;i < this.bufferList.size();i++){
            if(this.bufferList.get(i).isBufferFree()){
                returnBufferList.add(this.bufferList.get(i).getStatus());
            }else{
                returnBufferList.addAll(this.bufferList.get(i).getCStatus());
            }
        }
        return returnBufferList;
    }

    private String getBStatus(ArrayList<String> bufferStatusList) {
        ArrayList<String> bufferCountList = new ArrayList();
        if(bufferStatusList !=null){
            while(bufferStatusList.size()>0){
                String checkValue = bufferStatusList.get(0);
                int checkCount = 1;
                for(int i = 1;i < bufferStatusList.size();i++){
                    if(bufferStatusList.get(i).equals(checkValue)){
                        checkCount = checkCount+1;
                        bufferStatusList.remove(i);
                        i = 0;
                    }
                }
                bufferCountList.add(String.format("%d %s",checkCount,checkValue));
                bufferStatusList.remove(0);
            }
        }
        Collections.reverse(bufferCountList);
        StringBuilder debugStatus = new StringBuilder();
        for(String i : bufferCountList){
            debugStatus.append(i);
            debugStatus.append(", ");
        }
        return debugStatus.toString();
    }

    public Object requestB(int requestSize){
        Object returnValue = "-1";
        Object requestResponse = null;
        for(int i = 0;i<bufferList.size();i++){
            if(bufferList.get(i).isBufferFree()){
                requestResponse = bufferList.get(i).requestBuffer(requestSize);
                if(requestResponse == "-2"){
                    returnValue = "-2";
                    break;
                }else if (requestResponse == "-1"){
                    returnValue = "-1";
                }else {
                    this.tightPool = checkTight();
                    returnValue = requestResponse;
                    break;
                }
            }else if(bufferList.get(i).isBufferSplit()){
                requestResponse = bufferList.get(i).requestChild(requestSize);
                if(requestResponse == "-2"){
                    returnValue = "-2";
                    break;
                }else if (requestResponse == "-1"){
                    returnValue = "-1";
                }else {
                    this.tightPool = checkTight();
                    returnValue = requestResponse;
                    break;
                }
            }
        }
        setStatus(bufferDebug());
        return returnValue ;
    }

    private boolean checkTight() {
        int free = 0;
        for(int i = 0;i < bufferList.size();i++){
            if(bufferList.get(i).isBufferFree()){
                free = free+1;
            }
        }

        return free < 2;
    }

    public void returnB(Buffers addess){
        for(int i = 0;i < bufferList.size();i++){
            if(bufferList.get(i).reclaimeB(addess)==addess){
                this.tightPool = checkTight();
                break;
            }
        }
    }

    public int[] status(){
        ArrayList<String> bufferCountList = buildAvailableBt();
        int[] bufferStatusList = {0,0,0,0,0,0,0};
        for(int i = 0;i<bufferCountList.size();i++){
            if(bufferCountList.get(i).equals("511 size buffer")){
                bufferStatusList[0] = bufferStatusList[0] +1;
            }else if(bufferCountList.get(i).equals("255 size buffer")){
                bufferStatusList[1] = bufferStatusList[1] +1;
            }else if(bufferCountList.get(i).equals("127 size buffer")){
                bufferStatusList[2] = bufferStatusList[2] +1;
            }else if(bufferCountList.get(i).equals("63 size buffer")){
                bufferStatusList[3] = bufferStatusList[3] +1;
            }else if(bufferCountList.get(i).equals("31 size buffer")){
                bufferStatusList[4] = bufferStatusList[4] +1;
            }else if(bufferCountList.get(i).equals("15 size buffer")){
                bufferStatusList[5] = bufferStatusList[5] +1;
            }else if(bufferCountList.get(i).equals("7 size buffer")){
                bufferStatusList[6] = bufferStatusList[6] +1;
            }
        }

        return bufferStatusList;
    }


}

class Buffers {

    private int maxSize;
    private int minSize;
    private int currentSize;
    private Buffers parent = null;
    private Buffers childA = null;
    private Buffers childB = null;
    private boolean bufferFree = true;
    private boolean bufferSplit = false;
    private String controlWord = null;
    private Object requestResponse;
    private Buffers thisBuffer = this;
    
    public String getStatus() {
        return String.format("%s size buffer", this.currentSize);
    }

    public int getMaxSize() {
        return maxSize;
    }

    public int getMinSize() {
        return minSize;
    }

    public int getCurrentSize() {
        return currentSize;
    }

    public Buffers getParent() {
        return parent;
    }

    public Buffers getChildA() {
        return childA;
    }

    public Buffers getChildB() {
        return childB;
    }

    public boolean isBufferFree() {
        return bufferFree;
    }

    public boolean isBufferSplit() {
        return bufferSplit;
    }

    public String getControlWord() {
        return controlWord;
    }

    public String bufferToString() {
        return this.thisBuffer.toString();
    }

    public void Buffer(int maxSize, int minSize, Buffers parent) {
        this.maxSize = maxSize;
        this.minSize = minSize;
        this.currentSize = maxSize;
        this.parent = parent;
    }

    public Object requestBuffer(int requestSize) {
        return this.requestResponse = checkR(requestSize);
    }

    public Object requestChild(int requestSize) {
        return this.requestResponse = checkChR(requestSize);
    }

    private Object checkR(int requestSize) {
        if (requestSize > this.maxSize) {
            return "-2";
        } else if (requestSize > currentSize) {
            return "-1";
        } else {
            if (currentSize <= minSize+1) {
                setCW(requestSize);
                return this.thisBuffer;
            } else if (requestSize > (currentSize / 2)) {
                setCW(requestSize);
                return this.thisBuffer;
            } else {
                return splitB(requestSize);
            }
        }
    }

    private Object checkChR(int requestSize) {
        if (requestSize > this.maxSize) {
            return "-2";
        } else if (requestSize > currentSize) {
            return "-1";
        } else {
            Buffers child = freeCh();
            if(child == null){
                return "-1";
            }else{
                if(child.isBufferFree() && child.currentSize <= minSize+1){
                    child.setCW(requestSize);
                    return child.thisBuffer;
                }else if(child.isBufferFree() && requestSize > (child.currentSize / 2)) {
                    child.setCW(requestSize);
                    return child.thisBuffer;
                }else {
                    return child.checkR(requestSize);
                }
            }
        }
    }

    private Buffers freeCh() {
        if(this.childA.isBufferFree()){
            return childA;
        }else if(this.childB.isBufferFree()){
            return childB;
        }
        return null;
    }

    private Object splitB(int requestSize) {
        Buffers childA = new Buffers();
        childA.Buffer(this.maxSize / 2, 7, this.thisBuffer);
        this.childA = childA;
        Buffers childB = new Buffers();
        childB.Buffer(this.maxSize / 2, 7, this.thisBuffer);
        this.childB = childB;
        this.bufferFree = false;
        this.bufferSplit = true;


        return childA.checkR(requestSize);

    }

    public Buffers reclaimeB(Buffers returnedAddress) {
        if (returnedAddress == this.thisBuffer) {
            this.controlWord = null;
            this.bufferFree = true;
            this.bufferSplit = false;
            return this.thisBuffer;
        } else if (this.childA == null && this.childB == null) {
            return new Buffers();
        } else if (this.bufferSplit = true) {
            if (childA.reclaimeB(returnedAddress) == returnedAddress || childB.reclaimeB(returnedAddress) == returnedAddress) {
                this.childA = null;
                this.childB = null;
                this.bufferFree = true;
                this.bufferSplit = false;
                return returnedAddress;
            } else {
                return new Buffers();
            }
        }
        return new Buffers();
    }

    private void setCW(int request) {
        if(this.parent !=null){
            this.controlWord = this.currentSize + " " + getS();
        }else {
            this.controlWord = this.thisBuffer.toString()+"";
        }
        this.bufferFree = false;
    }

    private String getS() {
        String sibling = "null";
        ArrayList<Buffers> siblings = this.parent.getC();
        if (siblings.get(0) == this) {
            return siblings.get(1).toString();
        } else {
            return siblings.get(0).toString();
        }
    }

    private ArrayList<Buffers> getC() {
        ArrayList<Buffers> children = new ArrayList<>();
        children.add(this.childA);
        children.add(this.childB);
        return children;
    }

    public ArrayList getCStatus() {
        ArrayList childrenStatus = new ArrayList();
        if(this.childA!= null && !this.childA.isBufferSplit()){
            childrenStatus.add(this.childA.getStatus());
        }else if(this.childA != null){
            childrenStatus.addAll(this.childA.getCStatus());
        }
        if(this.childB != null && !this.childB.isBufferSplit()){
            childrenStatus.add(this.childB.getStatus());
        }else if(this.childB != null){
            childrenStatus.addAll(this.childB.getCStatus());
        }
        return childrenStatus;
    }

}

