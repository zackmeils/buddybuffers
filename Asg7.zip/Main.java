/**
* Zack Meilstrup, Asg 7, 5/11/2023
* This code is a tester/main class that uses the other classes to run a buddy buffer.
**/




import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedList;

public class Main {

    public static void main(String[] args){
        LinkedList<String> outputData = new LinkedList<>();
        outputData.add("Zack Meilstrup, 05/11/2023, Assignment 7\n\n\n");
        outputData.add("Initializing buffers");
        outputData = tb1(outputData);
        outputData = tb2(outputData);
        outputData = tb3(outputData);
        outputData = tb4(outputData);
        outputData = tb5(outputData);


        /**
         * The output data is sent to a file named BuddyBufferOutput.txt
         **/
        try {
            File userDirectory = new File(System.getProperty("user.dir"));
            File outputFile = Files.createFile("Asg7Output", userDirectory.getPath());
            Files.writeToFile(outputFile, outputData);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private static LinkedList<String> tb1(LinkedList<String> outputData) {
        BufferManager testB = new BufferManager();
        testB.BufferManager(10,511,7);
        ArrayList<Object> requestResponse = new ArrayList<>();
        outputData = (printStatus(testB.status(), outputData));
        outputData.add("Requesting 700");
        outputData.add("Expected values:");
        int[] testV = {700};
        return outputData = runTestDriver(testV,testB,outputData,requestResponse);    }

    private static LinkedList<String> tb2(LinkedList<String> outputData) {
        BufferManager testB = new BufferManager();
        testB.BufferManager(10,511,7);
        ArrayList<Object> requestResponse = new ArrayList<>();
        outputData.add("Requesting 7");
        outputData.add("Expected values: 9 510 size buffers, 1 254 size buffer, 1 126 size buffer, 1 62 size buffer, 1 30 size buffer, 1 14 size buffer and 1 6 size buffer, Status OK");
        int[] testV = {7};
        return outputData = runTestDriver(testV,testB,outputData,requestResponse);    }

    private static LinkedList<String> tb3(LinkedList<String> outputData) {
        BufferManager testB = new BufferManager();
        testB.BufferManager(10,511,7);
        ArrayList<Object> requestResponse = new ArrayList<>();
        outputData.add("Requesting 10 510 buffers");
        outputData.add("Expected values:0 510 buffers, 0 for all buffers, Status Tight ");
        int[] testV = {511,511,511,511,511,511,511,511,511,511};
        outputData = runTestDriver(testV, testB, outputData, requestResponse);
        ArrayList<Object> requestResponse2 = new ArrayList<>();
        outputData.add("Requesting 62");
        outputData.add("Expected values: -1, Status Tight");
        int[] testV2 = {62};
        return outputData = runTestDriver(testV2,testB,outputData,requestResponse2);    }

    private static LinkedList<String> tb4(LinkedList<String> outputData) {
        BufferManager testB = new BufferManager();
        testB.BufferManager(10,511,7);
        ArrayList<Object> requestResponse = new ArrayList<>();
        outputData.add("Request 19 254 size buffers");
        outputData.add("Expected values: 0 510 buffers, 19 254 size buffers, 0 126 size buffers, 0 62 size buffers, 0 30 size buffers, 0 14 size buffers, 0 6 size buffers Status Tight ");
        int[] testV = {253,253,253,253,253,253,253,253,253,253,253,253,253,253,253,253,253,253,253};
        return outputData = runTestDriver(testV,testB,outputData, requestResponse);
    }

    private static LinkedList<String> tb5(LinkedList<String> outputData){
        BufferManager testB = new BufferManager();
        testB.BufferManager(10,511,7);
        ArrayList<Object> requestResponse = new ArrayList<>();
        outputData.add("Request 5 size 6, 2 size 254, 2 size 126, 7 510 size");
        outputData.add("Expected Values: 1 510 size buffers, 0 254 size buffer, 1 126 size buffer, 1 62 size buffer, 0 30 size buffer, 1 14 size buffer    and 1 6 size buffer, Status tight");
        int[] testV = {6,6,6,6,6,254,254,126,126,510,510,510,510,510,510,510,510};
        return outputData = runTestDriver(testV,testB,outputData,requestResponse);
    }

    private static LinkedList<String> runTestDriver(int[] requestSize, BufferManager bufferManager, LinkedList outputData, ArrayList<Object> requestResponse) {
        outputData = printStatus(bufferManager.status(), outputData);
        for(int i = 0;i < requestSize.length;i++){
            requestResponse.add(bufferManager.requestB(requestSize[i]));
            outputData.add("\nActual = Assigned address: " + requestResponse.get(i).toString());
        }
        outputData = printStatus(bufferManager.status(), outputData);
        outputData.add("\nStatus: "+bufferManager.getStatus());
        return outputData;
    }

    private static LinkedList<String> runReturnTestDriver(int[] requestSize, BufferManager bufferManager, LinkedList output, ArrayList<Object> requestR) {
        output = printStatus(bufferManager.status(), output);
        for(int i = 0;i < requestSize.length;i++){
            requestR.add(bufferManager.requestB(requestSize[i]));
            output.add("\nActual = Assigned address: " + requestR.get(i).toString());
        }
        output = printStatus(bufferManager.status(), output);
        output.add("Return buffer size: " + requestSize[0]);
        output.add("Expected values: 10 510 size buffers, Status OK");
        for(int i = 0;i<requestR.size();i++){
            bufferManager.returnB((Buffers) requestR.get(i));
        }
        output = printStatus(bufferManager.status(), output);
        output.add("\nStatus: "+bufferManager.getStatus());
        return output;
    }
    /**
     * Prints buffer status
     * */
    private static LinkedList printStatus(int[] bufferC, LinkedList output){
        output.add("\nFree Buffer Count:");
        output.add(bufferC[0] + " 510 size buffers");
        output.add(bufferC[1] + " 254 size buffers");
        output.add(bufferC[2] + " 126 size buffers");
        output.add(bufferC[3] + " 62 size buffers");
        output.add(bufferC[4] + " 30 size buffers");
        output.add(bufferC[5] + " 14 size buffers");
        output.add(bufferC[6] + " 6 size buffers");
        return output;
    }
}

class Files {

    public Files() {
    }

    public static ArrayList<String> readFileInput(File inputFile) {
        ArrayList<String> fileList = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(inputFile.getPath()));
            String readLine;
            while ((readLine = bufferedReader.readLine()) != null) {
                fileList.add(readLine);
            }
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFound: No file at specified file path" + inputFile.getPath());
        } catch (IOException e) {
            System.out.println("IOException: No data in selected file");
        }
        return fileList;
    }

    public static File createFile(String fileName, String fileDirectory) throws IOException {
        File newFile = new File(String.format("%s\\%s.txt", fileDirectory, fileName));
        newFile.createNewFile();
        return newFile;
    }

    public static void writeToFile(File fileName, LinkedList<String> outputList) {

        try {
            PrintStream writer = new PrintStream(new FileOutputStream(fileName));
            for(int i =0;i<outputList.size();i++){
                writer.println(outputList.get(i));
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

